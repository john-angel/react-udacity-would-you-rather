import React from 'react'
import '../App.css';

const Poll = props => {

    return(
        <div>
            <p>Would you rather?</p>
            <p>{props.data.optionOne.text} Votes: {props.data.optionOne.votes.length} - {(props.data.optionOne.votes.length/(props.data.optionOne.votes.length + props.data.optionTwo.votes.length))*100} %</p>
            <p>{props.data.optionTwo.text} Votes: {props.data.optionTwo.votes.length} - {(props.data.optionTwo.votes.length/(props.data.optionOne.votes.length + props.data.optionTwo.votes.length))*100} %</p>
			<img src={props.data.authorAvatarURL}
                 alt={props.data.authorName}
                 className='avatar'
            />
            <p>Author: {props.data.authorName}</p>
            <p>Date: {new Date(props.data.timestamp).toDateString()}</p>
        </div>
    )
}

export default Poll
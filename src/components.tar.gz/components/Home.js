import React, { Component,Fragment} from 'react';
import { connect } from 'react-redux'
import {handleGetQuestions} from '../actions/questions'

import NavBar from './NavBar'
import PollsUnanswered from './PollsUnanswered'
import PollsAnswered from './PollsAnswered'
import Leaderboard from './Leaderboard'

class Home extends Component{

    componentDidMount(){
        this.props.dispatch(handleGetQuestions())
    }

    render() {
        return (
            <Fragment>
                <NavBar>
                </NavBar>
                <Leaderboard />
            </Fragment>
        )
    }
}

export default connect()(Home)
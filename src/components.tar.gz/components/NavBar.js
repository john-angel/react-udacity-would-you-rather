import React from 'react';
import { connect } from 'react-redux'
import { NavLink } from 'react-router-dom'

const NavBar = (props) => {

    return (

        <nav className='nav'>
            <ul>
                <li>
                    <NavLink to="/home">
                        Answered
                        </NavLink>
                </li>
                <li>
                    <NavLink to="/home">
                        Unanswered
                        </NavLink>
                </li>
                <li>
                    <NavLink to="/home">
                        Leaderboard
                        </NavLink>
                </li>
                <li>
                    <NavLink to="/">
                        {props.user} - LogOut
                    </NavLink>
                </li>
            </ul>
        </nav>
    )

}

const mapStateToProps = state => {
    return { user: 'Test' }//state.users[state.authUser].name
}

export default connect(mapStateToProps)(NavBar)